#!/bin/sh

killall -SIGINT gpu-screen-recorder
