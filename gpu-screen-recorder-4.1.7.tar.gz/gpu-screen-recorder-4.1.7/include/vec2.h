#ifndef VEC2_H
#define VEC2_H

typedef struct {
    int x, y;
} vec2i;

typedef struct {
    float x, y;
} vec2f;

#endif /* VEC2_H */
